const App = () => {
  return (
    <div className="bg-[#F5F5F5]">
      <div className="bg-[#709A5A] p-4 lg:px-16 flex justify-between items-center border border-[#464C4A]">
        <div className="flex items-center">
          <img alt="Company Logo" className="h-15 w-20 mr-2" src="/logo.png" />
          <div className="flex flex-col items-center">
            <p className="text-[#1E1E1E] text-2xl font-bold">BUCKEYE</p>
            <p className="text-[#1E1E1E] text-xs">-WEB SOLUTIONS-</p>
          </div>
        </div>
        <nav className="flex gap-x-8 items-center">
          <a className="text-white" href="/">
            Home
          </a>
          <a className="text-white" href="/">
            Services
          </a>
          <a className="text-white" href="/">
            Portfolio
          </a>
          <a className="text-white" href="/">
            About us
          </a>
          <button
            className="bg-white text-[#1E1E1E] px-4 py-2 rounded-full border border-[#464C4A]"
            href="/"
          >
            Contact us
          </button>
        </nav>
      </div>
      <div className="text-center mt-10">
        <h1 className="text-4xl font-bold">Get your Estimated Budget Today</h1>
        <p className="text-gray-600 mt-2">
          Morem ipsum dolor sit amet, consectetur adipiscing elit.
        </p>
      </div>
      <div className="max-w-4xl mx-auto mt-10">
        <div className="bg-white p-6 rounded-lg shadow-lg mb-10">
          <div className="flex items-center mb-4">
            <div className="w-8 h-8 bg-green-700 text-white rounded-full flex items-center justify-center">
              1
            </div>
            <div className="flex-1 h-1 bg-green-700 mx-2"></div>
            <div className="w-8 h-8 bg-gray-300 text-gray-600 rounded-full flex items-center justify-center">
              2
            </div>
            <div className="flex-1 h-1 bg-gray-300 mx-2"></div>
            <div className="w-8 h-8 bg-gray-300 text-gray-600 rounded-full flex items-center justify-center">
              3
            </div>
            <div className="flex-1 h-1 bg-gray-300 mx-2"></div>
            <div className="w-8 h-8 bg-gray-300 text-gray-600 rounded-full flex items-center justify-center">
              4
            </div>
          </div>
          <h2 className="text-xl font-bold mb-4">Basic Information</h2>
          <form>
            <div className="mb-4">
              <label className="block text-gray-700">Business Name</label>
              <input
                className="w-full p-2 border rounded"
                placeholder="Enter your business name"
                type="text"
              />
            </div>
            <div className="mb-4">
              <label className="block text-gray-700">Contact Name</label>
              <input
                className="w-full p-2 border rounded"
                placeholder="Enter your contact name"
                type="text"
              />
            </div>
            <div className="mb-4">
              <label className="block text-gray-700">Email Address</label>
              <input
                className="w-full p-2 border rounded"
                placeholder="Enter your email address"
                type="email"
              />
            </div>
            <button className="bg-green-700 text-white px-4 py-2 rounded">
              Continue →
            </button>
          </form>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-lg mb-10">
          <div className="flex items-center mb-4">
            <div className="w-8 h-8 bg-green-700 text-white rounded-full flex items-center justify-center">
              1
            </div>
            <div className="flex-1 h-1 bg-green-700 mx-2"></div>
            <div className="w-8 h-8 bg-green-700 text-white rounded-full flex items-center justify-center">
              2
            </div>
            <div className="flex-1 h-1 bg-green-700 mx-2"></div>
            <div className="w-8 h-8 bg-gray-300 text-gray-600 rounded-full flex items-center justify-center">
              3
            </div>
            <div className="flex-1 h-1 bg-gray-300 mx-2"></div>
            <div className="w-8 h-8 bg-gray-300 text-gray-600 rounded-full flex items-center justify-center">
              4
            </div>
          </div>
          <h2 className="text-xl font-bold mb-4">Services Needed</h2>
          <form>
            <div className="mb-4">
              <label className="block text-gray-700">Required Service(s)</label>
              <select className="w-full p-2 border rounded">
                <option>Choose your desired services</option>
              </select>
            </div>
            <div className="mb-4">
              <label className="block text-gray-700">Project Description</label>
              <textarea
                className="w-full p-2 border rounded"
                placeholder="What are your requirements"
              ></textarea>
            </div>
            <div className="flex justify-between">
              <button className="bg-gray-300 text-gray-700 px-4 py-2 rounded">
                Back ←
              </button>
              <button className="bg-green-700 text-white px-4 py-2 rounded">
                Continue →
              </button>
            </div>
          </form>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-lg mb-10">
          <div className="flex items-center mb-4">
            <div className="w-8 h-8 bg-green-700 text-white rounded-full flex items-center justify-center">
              1
            </div>
            <div className="flex-1 h-1 bg-green-700 mx-2"></div>
            <div className="w-8 h-8 bg-green-700 text-white rounded-full flex items-center justify-center">
              2
            </div>
            <div className="flex-1 h-1 bg-green-700 mx-2"></div>
            <div className="w-8 h-8 bg-green-700 text-white rounded-full flex items-center justify-center">
              3
            </div>
            <div className="flex-1 h-1 bg-green-700 mx-2"></div>
            <div className="w-8 h-8 bg-gray-300 text-gray-600 rounded-full flex items-center justify-center">
              4
            </div>
          </div>
          <h2 className="text-xl font-bold mb-4">Project Budget</h2>
          <form>
            <div className="mb-4">
              <label className="block text-gray-700">Budget Range</label>
              <input
                className="w-full p-2 border rounded"
                placeholder="Select budget range"
                type="text"
              />
            </div>
            <div className="mb-4">
              <label className="block text-gray-700">Preferred Timeline</label>
              <input
                className="w-full p-2 border rounded"
                placeholder="Preferred start date"
                type="text"
              />
            </div>
            <div className="mb-4">
              <label className="block text-gray-700">
                Estimated Project Duration
              </label>
              <input
                className="w-full p-2 border rounded"
                placeholder="Enter project duration (in months)"
                type="text"
              />
            </div>
            <div className="flex justify-between">
              <button className="bg-gray-300 text-gray-700 px-4 py-2 rounded">
                Back ←
              </button>
              <button className="bg-green-700 text-white px-4 py-2 rounded">
                Continue →
              </button>
            </div>
          </form>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-lg mb-10">
          <div className="flex items-center mb-4">
            <div className="w-8 h-8 bg-green-700 text-white rounded-full flex items-center justify-center">
              1
            </div>
            <div className="flex-1 h-1 bg-green-700 mx-2"></div>
            <div className="w-8 h-8 bg-green-700 text-white rounded-full flex items-center justify-center">
              2
            </div>
            <div className="flex-1 h-1 bg-green-700 mx-2"></div>
            <div className="w-8 h-8 bg-green-700 text-white rounded-full flex items-center justify-center">
              3
            </div>
            <div className="flex-1 h-1 bg-green-700 mx-2"></div>
            <div className="w-8 h-8 bg-green-700 text-white rounded-full flex items-center justify-center">
              4
            </div>
          </div>
          <h2 className="text-xl font-bold mb-4">Confirm Details</h2>
          <div className="mb-4">
            <label className="block text-gray-700">Business Name</label>
            <p className="p-2 border rounded bg-gray-100">Acme Corporation</p>
          </div>
          <div className="mb-4">
            <label className="block text-gray-700">Services</label>
            <p className="p-2 border rounded bg-gray-100">
              Web Dev, UI/UX Design
            </p>
          </div>
          <div className="mb-4">
            <label className="block text-gray-700">Budget Range</label>
            <p className="p-2 border rounded bg-gray-100">$10,000 - $20,000</p>
          </div>
          <div className="flex justify-between">
            <button className="bg-gray-300 text-gray-700 px-4 py-2 rounded">
              Back ←
            </button>
            <button className="bg-green-700 text-white px-4 py-2 rounded">
              Submit →
            </button>
          </div>
        </div>
      </div>
      <footer className="bg-green-700 text-white p-6 mt-10">
        <div className="max-w-4xl mx-auto flex justify-between">
          <div className="flex items-center">
            <img
              alt="Company Logo"
              className="h-10 w-10 mr-2"
              height="50"
              src="https://storage.googleapis.com/a1aa/image/1XcaQRPhYjJ6OloGhXXcsCyLtc0N8uHKt3PiXFKZmzfbxeyTA.jpg"
              width="50"
            />
            <div>
              <span className="text-xl font-bold">BUCKEYE</span>
              <span className="text-sm block">-WEB SOLUTIONS-</span>
              <span className="text-xs block">
                Crafting Digital Solutions for Business Growth.
              </span>
            </div>
          </div>
          <div className="flex space-x-10">
            <div>
              <h3 className="font-bold mb-2">QUICK LINKS</h3>
              <ul>
                <li>
                  <a className="text-white" href="/">
                    Home
                  </a>
                </li>
                <li>
                  <a className="text-white" href="/">
                    Services
                  </a>
                </li>
                <li>
                  <a className="text-white" href="/">
                    Portfolio
                  </a>
                </li>
                <li>
                  <a className="text-white" href="/">
                    About us
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold mb-2">LEGAL</h3>
              <ul>
                <li>
                  <a className="text-white" href="/">
                    Privacy Policy
                  </a>
                </li>
                <li>
                  <a className="text-white" href="/">
                    Terms of use
                  </a>
                </li>
                <li>
                  <a className="text-white" href="/">
                    Refund and Cancellation Policy
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold mb-2">GET IN TOUCH</h3>
              <ul>
                <li>
                  <a className="text-white" href="mailto:support@mail.com">
                    support@mail.com
                  </a>
                </li>
                <li>
                  <a className="text-white" href="tel:+02020202021">
                    +02020202021
                  </a>
                </li>
                <li>
                  <a className="text-white" href="/">
                    abc street, abc city, USA
                  </a>
                </li>
                <li className="flex space-x-2 mt-2">
                  <a className="text-white" href="/">
                    <i className="fab fa-facebook"></i>
                  </a>
                  <a className="text-white" href="/">
                    <i className="fab fa-instagram"></i>
                  </a>
                  <a className="text-white" href="/">
                    <i className="fab fa-linkedin"></i>
                  </a>
                  <a className="text-white" href="/">
                    <i className="fab fa-envelope"></i>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div className="text-center mt-6 text-xs">
          Copyright © 2024 Buckeye Media Solutions Pvt. Ltd. All Rights
          Reserved.
        </div>
      </footer>
    </div>
  );
};

export default App;
