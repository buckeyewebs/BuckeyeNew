const Footer = () => {
  return (
    <footer className="bg-[#709A5A] text-white p-6 mt-10 inknut-antiqua">
      <div className="max-w-7xl mx-auto flex flex-col lg:flex-row justify-between">
        <div>
          {/* Logo and Description */}
          <div className="flex items-center mb-6 lg:mb-0">
            <img
              alt="Company Logo"
              className="h-10 md:h-20 md:w-28 w-10 mr-3"
              height="50"
              src="/logo.png"
              width="50"
            />
            <div className="flex flex-col items-center text-[#2E2E2E]">
              <span className="text-xl font-bold">BUCKEYE</span>
              <span className="text-sm block">-WEB SOLUTIONS-</span>
            </div>
          </div>
          <p className="text-xs block text-white">
            Crafting Digital Solutions for Business Growth.
          </p>
        </div>

        {/* Footer Links */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Quick Links */}
          <div>
            <h3 className="font-bold mb-2">QUICK LINKS</h3>
            <ul>
              <li>
                <a className="relative text-[#2E2E2E] group" href="/">
                  Home
                  <span className="absolute left-0 bottom-0 w-0 h-[2px] bg-white transition-all duration-300 group-hover:w-full"></span>
                </a>
              </li>
              <li>
                <a className="relative text-[#2E2E2E] group" href="/">
                  Services
                  <span className="absolute left-0 bottom-0 w-0 h-[2px] bg-white transition-all duration-300 group-hover:w-full"></span>
                </a>
              </li>
              <li>
                <a className="relative text-[#2E2E2E] group" href="/">
                  Portfolio
                  <span className="absolute left-0 bottom-0 w-0 h-[2px] bg-white transition-all duration-300 group-hover:w-full"></span>
                </a>
              </li>
              <li>
                <a className="relative text-[#2E2E2E] group" href="/">
                  About us
                  <span className="absolute left-0 bottom-0 w-0 h-[2px] bg-white transition-all duration-300 group-hover:w-full"></span>
                </a>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="font-bold mb-2">LEGAL</h3>
            <ul>
              <li>
                <a className="relative text-[#2E2E2E] group" href="/">
                  Privacy Policy
                  <span className="absolute left-0 bottom-0 w-0 h-[2px] bg-white transition-all duration-300 group-hover:w-full"></span>
                </a>
              </li>
              <li>
                <a className="relative text-[#2E2E2E] group" href="/">
                  Terms of use
                  <span className="absolute left-0 bottom-0 w-0 h-[2px] bg-white transition-all duration-300 group-hover:w-full"></span>
                </a>
              </li>
              <li>
                <a className="relative text-[#2E2E2E] group" href="/">
                  Refund and Cancellation Policy
                  <span className="absolute left-0 bottom-0 w-0 h-[2px] bg-white transition-all duration-300 group-hover:w-full"></span>
                </a>
              </li>
            </ul>
          </div>

          {/* Get in Touch */}
          <div>
            <h3 className="font-bold mb-2">GET IN TOUCH</h3>
            <ul>
              <li>
                <a
                  className="relative text-[#2E2E2E] group"
                  href="mailto:support@mail.com"
                >
                  support@mail.com
                  <span className="absolute left-0 bottom-0 w-0 h-[2px] bg-white transition-all duration-300 group-hover:w-full"></span>
                </a>
              </li>
              <li>
                <a
                  className="relative text-[#2E2E2E] group"
                  href="tel:+02020202021"
                >
                  +02020202021
                  <span className="absolute left-0 bottom-0 w-0 h-[2px] bg-white transition-all duration-300 group-hover:w-full"></span>
                </a>
              </li>
              <li>
                <a className="relative text-[#2E2E2E] group" href="/">
                  abc street, abc city, USA
                  <span className="absolute left-0 bottom-0 w-0 h-[2px] bg-white transition-all duration-300 group-hover:w-full"></span>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Footer Bottom Text */}
      <div className="text-center mt-6 text-xs text-[#2E2E2E]">
        Copyright © 2024 Buckeye Media Solutions Pvt. Ltd. All Rights Reserved.
      </div>
    </footer>
  );
};

export default Footer;
