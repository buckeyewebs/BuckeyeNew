import { useState } from "react";
import { Menu, X } from "lucide-react";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeLink, setActiveLink] = useState(null);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const navLinks = [
    { label: "Home", href: "/" },
    { label: "Services", href: "/services" },
    { label: "Portfolio", href: "/portfolio" },
    { label: "About us", href: "/about" },
  ];

  return (
    <div className="relative bg-[#709A5A] p-4 lg:px-16 flex justify-between items-center border border-[#464C4A] inknut-antiqua-semibold">
      {/* Logo Section with Hover Effect */}
      <div
        className="flex items-center cursor-pointer transform transition-transform duration-300 hover:scale-105"
        onClick={() => (window.location.href = "/")}
      >
        <img
          alt="Company Logo"
          className="h-15 w-20 mr-2 transition-transform duration-300 hover:rotate-6"
          src="/logo.png"
        />
        <div className="flex flex-col items-center">
          <p className="text-[#1E1E1E] text-2xl font-bold transition-colors duration-300 group-hover:text-white">
            BUCKEYE
          </p>
          <p className="text-[#1E1E1E] text-xs">-WEB SOLUTIONS-</p>
        </div>
      </div>

      {/* Hamburger Menu for Mobile */}
      <button
        className="lg:hidden absolute right-4 top-1/2 -translate-y-1/2 z-50 
        transform transition-transform hover:scale-110 active:scale-95"
        onClick={toggleMenu}
      >
        {isMenuOpen ? (
          <X size={24} color="white" />
        ) : (
          <Menu size={24} color="white" />
        )}
      </button>

      {/* Navigation Menu */}
      <nav
        className={`
        fixed inset-0 bg-[#709A5A] z-40 flex flex-col justify-center items-center
        lg:static lg:flex lg:flex-row lg:bg-transparent lg:z-0
        transform transition-transform duration-300 ease-in-out
        ${isMenuOpen ? "translate-x-0" : "translate-x-full"}
        lg:translate-x-0
      `}
      >
        <div className="flex flex-col lg:flex-row gap-8 items-center">
          {navLinks.map((link, index) => (
            <a
              key={link.href}
              className={`
                relative text-white text-2xl lg:text-base 
                transition-all duration-300 ease-in-out
                hover:text-[#1E1E1E] 
                group overflow-hidden
                ${activeLink === index ? "text-[#1E1E1E]" : ""}
              `}
              href={link.href}
              onClick={() => {
                toggleMenu();
                setActiveLink(index);
              }}
            >
              {/* Underline Hover Effect */}
              <span
                className="absolute bottom-0 left-0 w-full h-0.5 bg-[#1E1E1E] 
                transform -translate-x-full group-hover:translate-x-0 
                transition-transform duration-300 ease-in-out"
              />
              {link.label}
            </a>
          ))}

          {/* Contact Button with Enhanced Hover */}
          <button
            className="
              bg-white text-[#1E1E1E] 
              px-6 py-3 lg:px-4 lg:py-2 
              rounded-full border border-[#464C4A] 
              relative overflow-hidden
              group
              transition-all duration-300
              hover:bg-[#1E1E1E] hover:text-white
            "
            onClick={toggleMenu}
          >
            {/* Animated Background Hover Effect */}
            <span
              className="
                absolute top-0 left-0 w-full h-full 
                bg-[#709A5A] 
                transform -translate-x-full 
                group-hover:translate-x-0 
                transition-transform duration-300 
                z-0
              "
            />
            <span className="relative z-10">Contact us</span>
          </button>
        </div>
      </nav>
    </div>
  );
};

export default Header;
